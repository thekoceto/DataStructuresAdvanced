public class Main {
    public static void main(String[] args) {
        AVL<Integer> avl = new AVL<Integer>();

        for (int i = 0; i < 15; i++)
            avl.insert(i);

        System.out.println(avl.inOrderPrint());
    }
}
