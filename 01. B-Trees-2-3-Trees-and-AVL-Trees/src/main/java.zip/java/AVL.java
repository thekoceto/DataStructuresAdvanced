import java.util.function.Consumer;

public class AVL<T extends Comparable<T>> {

    private Node<T> root;

    public Node<T> getRoot() {
        return this.root;
    }

    public boolean contains(T item) {
        Node<T> node = this.search(this.root, item);
        return node != null;
    }

    public void insert(T item) {
        this.root = this.insert(this.root, item);
    }

    public void eachInOrder(Consumer<T> consumer) {
        this.eachInOrder(this.root, consumer);
    }

    private void eachInOrder(Node<T> node, Consumer<T> action) {
        if (node == null) {
            return;
        }

        this.eachInOrder(node.left, action);
        action.accept(node.value);
        this.eachInOrder(node.right, action);
    }

    private Node<T> insert(Node<T> node, T item) {
        if (node == null) {
            return new Node<>(item);
        }

        int cmp = item.compareTo(node.value);
        if (cmp < 0) {
            node.left = this.insert(node.left, item);
        } else if (cmp > 0) {
            node.right = this.insert(node.right, item);
        }

        int balance = getBalanceFactor(node);


        if (balance > 1) {
            if(item.compareTo(node.left.value) > 0)
                node.left = rotateLeft(node.left);
            node = rotateRight(node);
        }
        else if (balance < -1) {
            if(item.compareTo(node.right.value) < 0)
                node.right = rotateRight(node.right);
            node = rotateLeft(node);
        }

        updateHeight(node);

        return node;
    }

    private int getBalanceFactor(Node<T> node) {
        return getHeight(node.left) - getHeight(node.right);
    }

    private Node<T> search(Node<T> node, T item) {
        if (node == null) {
            return null;
        }

        int cmp = item.compareTo(node.value);
        if (cmp < 0) {
            return search(node.left, item);
        } else if (cmp > 0) {
            return search(node.right, item);
        }

        return node;
    }

    private void updateHeight(Node<T> node) {
        node.height =
                getHeight(node.left) > getHeight(node.right) ?
                getHeight(node.left) + 1 :
                getHeight(node.right) + 1;
    }

    private <T extends Comparable<T>> int getHeight(Node<T> node) {
        return node == null ? 0 : node.height;
    }

    private Node<T> rotateRight (Node<T> node) {
        //         [n(5)]     >>      [t(2)]
        //        /      \    >>     /     \
        //    [l(2)]   [r(#)] >> [l(#)]  [r(5)]
        //    /    \          >>         /    \
        // [l(#)] [r(3)]      >>      [l(3)] [r(#)]

        Node<T> top = node.left;        // [l(2)]
        node.left = node.left.right;    //
        top.right = node;

        updateHeight(node);
        updateHeight(top);

        return top;
    }

    private Node<T> rotateLeft (Node<T> node) {
        //      [n(2)]        >>         [t(5)]
        //     /     \        >>        /      \
        // [l(#)]  [r(5)]     >>    [l(2)]   [r(#)]
        //         /    \     >>    /    \
        //      [l(3)] [r(#)] >> [l(#)] [r(3)]

        Node<T> top = node.right;
        node.right = node.right.left;
        top.left = node;

        updateHeight(node);
        updateHeight(top);

        return top;
    }

    // ------------------
    public String inOrderPrint() {
        StringBuilder output = new StringBuilder();
        if (this.root != null)
            inOrderPrint(output, "", this.root);
        return output.toString();
    }

    private void inOrderPrint(StringBuilder output, String indent, Node<T> current) {

        if (current.right != null)
            this.inOrderPrint(output, indent + "  ", current.right);

        output
                .append(indent)
                .append(current.value).append("(").append(current.height).append(")")
                .append(System.lineSeparator());

        if (current.left != null)
            this.inOrderPrint(output, indent + "  ", current.left);

    }
}
